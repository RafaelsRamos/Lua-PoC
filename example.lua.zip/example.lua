-- Define a function to calculate the factorial of a number
function factorial(n)
    if n == 0 then
        return 1
    else
        return n * factorial(n - 1)
    end
end

-- Print the factorial of numbers from 0 to 9
for i = 0, 9 do
    print("Factorial of " .. i .. " is " .. factorial(i))
end

-- Define a table (Lua's associative array) with some key-value pairs
local fruits = {
    apple = "red",
    banana = "yellow",
    grape = "purple"
}

-- Iterate over the table and print each key-value pair
for fruit, color in pairs(fruits) do
    print("A " .. fruit .. " is " .. color)
end
